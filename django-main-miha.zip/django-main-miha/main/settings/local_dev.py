
import os

SECRET_KEY = 'l#i6$njjvz1pf6pg_!bubf(z0$q$0+)no5yx+l)q0ub%4xx_+9'

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'HOST': 's1-v-dbdev-1.main.eip',
                'NAME': 'cscd',
                'SCHEME': 'auth',
                'PORT': '5432',
                'USER': 'django_auth_user',
                'PASSWORD': 'django_auth_user',
    },
    'miha': {
        'ENGINE': 'django.db.backends.postgresql',
        'HOST': 's1-v-dbdev-1.main.eip',
                'NAME': 'mkadd_cscd',
                'SCHEME': 'mkadd',
                'PORT': '5432',
                'USER': 'd99320',
                'PASSWORD': 'z_99320',
    },
}

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

# Authentication
# HTTP_X_REMOTE_USER в окружении Apache
# LOGNAME в окружении manage.py
REMOTE_USER_HEADER = 'LOGNAME'
CREATE_UNKNOWN_USER = False
WHOAMI_URL = 'https://eci-web.eci.local/webportal/api/v1/user/whoami/'

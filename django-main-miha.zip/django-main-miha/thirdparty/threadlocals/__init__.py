# User: Troy Evans
# Date: 1/24/13
# Time: 8:06 PM
#
# Copyright 2012, Nutrislice Inc.
VERSION = '0.10'
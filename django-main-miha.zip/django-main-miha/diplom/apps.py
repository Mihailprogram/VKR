from django.apps import AppConfig


class DiplomConfig(AppConfig):
    name = 'diplom'
